package jdbctemplate.resources;

public class SpringConfig {

}
