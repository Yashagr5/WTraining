Spring Boot is the extension or a module of Spring Framework

Spring Boot is a framework for building the java application instantly or quickly with
minimum configuration to be done by the developers.

Spring Boot developers now needs to be focussed on Business Logic and Minimize the boiler Plate code

Advantages of using Spring boot
1. AutoConfiguration 
2. Starter Dependencies 
3. Embedded Tomcat Server /Jetty
4. Dependencies need not to add manually from maven repository
5. Explicit configuration provided by the developer in one property file (application.properties or application.yml)



https://start.spring.io/
